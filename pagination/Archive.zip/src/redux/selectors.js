export const getProducts = store => store.products;
export const getPageInfo = store => store.pageInfo;
